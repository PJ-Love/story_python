import pymysql
conn=pymysql.connect(host='localhost',user='root',passwd='qwer1234',port=3306,charset='utf8')
cur=conn.cursor()
cur.execute("create database wangyi;")
conn.select_db("wangyi")
# cur.execute("""
#     create table article(
#     id int,
#     name varchar(20)
#     );
# """)
# conn.select_db("wangyi")
cur.execute("""
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `articleId` varchar(255) COLLATE utf8_bin NOT NULL,
  `title` longtext COLLATE utf8_bin NOT NULL,
  `url` varchar(1024) COLLATE utf8_bin NOT NULL,
  `content` longtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `article_articleId` (`articleId`),
  KEY `article_url` (`url`)
);
""")

cur.execute("""
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentArticleId` varchar(255) COLLATE utf8_bin NOT NULL,
  `commentId` varchar(255) COLLATE utf8_bin NOT NULL,
  `content` longtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_commentId` (`commentId`),
  KEY `comment_parentArticleId` (`parentArticleId`)
);
""")