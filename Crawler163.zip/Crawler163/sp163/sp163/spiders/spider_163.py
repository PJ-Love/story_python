import scrapy
import re
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from sp163.items import ArticleItem, CommentItem


class Spider163(CrawlSpider):
    name = "163"
    allowed_domains = ["news.163.com"]
    start_urls = [
        # "http://news.163.com/",
        "http://temp.163.com/special/00804KVA/cm_yaowen_02.js?callback=data_callback",
        "http://temp.163.com/special/00804KVA/cm_yaowen_03.js?callback=data_callback",
        "http://temp.163.com/special/00804KVA/cm_yaowen_04.js?callback=data_callback",
        "http://temp.163.com/special/00804KVA/cm_yaowen_05.js?callback=data_callback",
        "http://temp.163.com/special/00804KVA/cm_yaowen_06.js?callback=data_callback",
        "http://temp.163.com/special/00804KVA/cm_yaowen_07.js?callback=data_callback",
    ]
    rules = (
        Rule(LinkExtractor(allow=r"/\d+/\d+/\d+/*"),
             callback="parse_news", follow=True),
    )
    news_url_id_re = re.compile(r'.*/\d+/\d+/\d+/(.*)\.html')#正则 编译为一个实例 再把实例去和文本匹配
    getData_jsonp = re.compile(r'getData\((.*)\);', re.S)
    data_callback_jsonp = re.compile(r'data_callback\((.*)\)', re.S)

    def parse_start_url(self, response):
        if response.url.startswith('http://temp.163.com'):
            import json
            data = response.body_as_unicode()
            data_m = self.data_callback_jsonp.match(data)
            data_json = data_m.group(1)
            json_response = json.loads(data_json)
            for j in json_response:
                j_url = j['docurl']
                if j_url.startswith('http://news.163.com'):
                    yield scrapy.Request(j_url, callback=self.parse_first)

    def parse_first(self, response):
        return self._parse_response(response, callback=self.parse_news, cb_kwargs={}, follow=True)

    def parse_news(self, response):
        id_m = self.news_url_id_re.match(response.url)
        if id_m:
            item = ArticleItem()
            item['url'] = response.url
            title = response.xpath("/html/head/title/text()").extract()
            end_text = response.xpath("//*[@id=\"endText\"]").extract()
            if len(title) and len(end_text) > 0:
                item['title'] = title[0]
                item['content'] = response.body_as_unicode()
                url_id = id_m.group(1)
                item['articleId'] = url_id
                url, next_offset = self.build_comment_url(url_id, 0)
                yield scrapy.Request(url, meta={'articleId': url_id, 'next_offset': next_offset},
                                     callback=self.parse_comment)
                yield item

        yield None

    def parse_comment(self, response):
        import json
        data = response.body_as_unicode()
        data_m = self.getData_jsonp.match(data)
        data_json = data_m.group(1)
        json_response = json.loads(data_json)
        comments = json_response['comments']
        article_id = response.meta['articleId']
        next_offset = response.meta['next_offset']
        if len(comments) > 0:
            for comment in comments.values():
                comment_item = CommentItem()
                comment_item['parentArticleId'] = article_id
                comment_item['commentId'] = comment['commentId']
                comment_item['content'] = comment['content']
                yield comment_item
            url, next_offset = self.build_comment_url(article_id, next_offset)
            yield scrapy.Request(url, meta={'articleId': article_id, 'next_offset': next_offset},
                                 callback=self.parse_comment)
        yield None

    @staticmethod
    def build_comment_url(url_id, offset):
        import time

        url = "http://comment.news.163.com/api/v1/products/a2869674571f77b5a0867c3d71db5856/threads" \
              "/{url_id}/comments/newList?offset={offset}&limit=30&showLevelThreshold=72&headLimit=1&tailLimit" \
              "=2&callback=getData&ibc=newspc&_={time}" \
            .format(url_id=url_id, offset=offset, time=int(time.time()))

        return url, offset + 30
