#-*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
from bs4 import BeautifulSoup
from sp163.items import ArticleItem, CommentItem
from sp163.model import connect_db


class Sp163ContentPipeline(object):#将得到的一大堆数据分类
    def soup_extract(self, soups):
        if len(soups) > 0:
            for soup in soups:
                soup.extract()#soup是经过BS处理格式化之后的字符串

    def process_item(self, item, spider):
        if isinstance(item, ArticleItem):
            content = item['content']
            content = BeautifulSoup(content, "lxml")#用了lxml解析器，速度快，容错能力强
            pres = content.select('#endText > pre')#通过id名进行查找
            self.soup_extract(pres)

            special_tag_wraps = content.select('#endText > div.special_tag_wrap')#返回类型是列表
            self.soup_extract(special_tag_wraps)

            item['content'] = content.select('#endText')[0].get_text()
            return item
        return item


class MySQLStoreCnblogsPipeline(object):
    def open_spider(self, spider):
        self.conn,self.cur = connect_db()

    def process_item(self, item, spider):
        print('proess')
        if isinstance(item, ArticleItem):
            print(1)
            self.cur.execute("insert into article(articleId,title,url,content) values (%s,%s,%s,%s)",[str(item['articleId']),str(item['title']),str(item['url']),str(item['content'])])
            self.conn.commit()

        if isinstance(item, CommentItem):
            print(2)
            self.cur.execute("insert into comment(parentArticleId,commentId,content) values (%s,%s,%s)",[str(item['parentArticleId']),str(item['commentId']),str(item['content'])])
            self.conn.commit()
        return item
