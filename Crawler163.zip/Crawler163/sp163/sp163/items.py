# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ArticleItem(scrapy.Item):
    # define the fields for your item here like:
    articleId = scrapy.Field()
    title = scrapy.Field()
    url = scrapy.Field()
    content = scrapy.Field()
    pass


class CommentItem(scrapy.Item):
    parentArticleId = scrapy.Field()
    commentId = scrapy.Field()
    content = scrapy.Field()
