import pymysql
def connect_db():
    conn=pymysql.connect(host='localhost',user='root',passwd='qwer1234',port=3306,charset='utf8',db="wangyi")
    cur=conn.cursor()
    return conn,cur
