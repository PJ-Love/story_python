import requests
from lxml import etree

from mysqlhelper import MysqlHelper
helper = MysqlHelper()

#     每一个队伍的球队阵容:
#     号码,	球员,	出生日,	身高(cm),	体重(kg),	位置,	国籍,
#     	进球,	助攻,	红牌,	黄牌, 主教练

def parse_detailed_leisu1(url):
    response = requests.get(url)
    response.encoding = 'utf-8'

    # 第三步 获取网页
    html_ele = etree.HTML(response.text)
    print(html_ele)

    tr_list = html_ele.xpath('/html/body/div[1]/div[2]/div[2]/div[1]/div[3]/div[2]/div[2]/table/tr')
    for tr in tr_list[1:]:
        trainer = html_ele.xpath('/html/body/div[1]/div[2]/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/text()')[0].strip()
        print(trainer) # 主教练
        number = tr.xpath('./td[1]/text()')[0].strip()
        print(number) # 号码
        qiuyuan = tr.xpath('./td[2]/a[2]/span/text()')[0].strip()
        print(qiuyuan) # 球员
        birth = tr.xpath('./td[3]/text()')[0].strip()
        print(birth) # 生日
        height = tr.xpath('./td[4]/text()')[0].strip()
        print(height) # 身高
        weight = tr.xpath('./td[5]/text()')[0].strip()
        print(weight) # 体重
        position = tr.xpath('./td[6]/text()')[0].strip()
        print(position) # 位置
        nation = tr.xpath('./td[7]/span/text()')
        if nation:
            nation = tr.xpath('./td[7]/span/text()')[0].strip()
            print(nation) # 国籍
        else:
            nation = '-'
            print(nation)
        jinqiu = tr.xpath('./td[8]/text()')[0].strip()
        print(jinqiu) # 进球
        zhugong = tr.xpath('./td[9]/text()')[0].strip()
        print(zhugong) # 助攻
        hongpai = tr.xpath('./td[10]/text()')[0].strip()
        print(hongpai) # 红牌
        huangpai = tr.xpath('./td[11]/text()')[0].strip()
        print(huangpai) # 黄牌

        text = [trainer, number, qiuyuan, birth, height, weight, position, nation, jinqiu, zhugong, hongpai, huangpai]
        print(text)

        save_mysql(text)


# 存储到mysql
def save_mysql(text):
    # 爬虫第五步
    insert_sql = 'INSERT INTO leisu_worldcup_qiudui(trainer, number, qiuyuan, birth, height, weight, position, nation, jinqiu, zhugong, hongpai, huangpai) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);'
    data = text
    helper.execute_modify_sql(insert_sql, data)

if __name__ == '__main__':
    team_list = ['//data.leisu.com/team-13447', '//data.leisu.com/team-13336', '//data.leisu.com/team-10584', '//data.leisu.com/team-13464', '//data.leisu.com/team-14227', '//data.leisu.com/team-13152', '//data.leisu.com/team-14298', '//data.leisu.com/team-11763', '//data.leisu.com/team-10234', '//data.leisu.com/team-10867', '//data.leisu.com/team-13448', '//data.leisu.com/team-13832', '//data.leisu.com/team-11606', '//data.leisu.com/team-13727', '//data.leisu.com/team-13728', '//data.leisu.com/team-11081', '//data.leisu.com/team-10477', '//data.leisu.com/team-10871', '//data.leisu.com/team-10315', '//data.leisu.com/team-11837', '//data.leisu.com/team-10869', '//data.leisu.com/team-11764', '//data.leisu.com/team-10586', '//data.leisu.com/team-11746', '//data.leisu.com/team-10316', '//data.leisu.com/team-11079', '//data.leisu.com/team-13613', '//data.leisu.com/team-12064', '//data.leisu.com/team-10476', '//data.leisu.com/team-14529', '//data.leisu.com/team-13365', '//data.leisu.com/team-10823']
    print(len(team_list))
    for i in team_list:
        url = 'https:' + i
        parse_detailed_leisu1(url)