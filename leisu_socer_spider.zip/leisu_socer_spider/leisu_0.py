import requests
from lxml import etree

# from mysqlhelper import MysqlHelper
# helper = MysqlHelper()
# 雷速:
#     世界杯:
#     赛程,时间,主队,比分(半场),客队,让球全场,让球半场,进球数全场,进球数半场,数据
#     每一个队伍的球队阵容:
#     号码,	球员,	出生日,	身高(cm),	体重(kg),	位置,	国籍,
#     	进球,	助攻,	红牌,	黄牌, 主教练

def parse_detailed_leisu(url):
    response = requests.get(url)
    response.encoding = 'utf-8'

    # 第三步 获取网页
    html_ele = etree.HTML(response.text)
    print(html_ele)

    # 世界杯分组赛
    # for i in range(2,66):
    #     lunci = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[1]/text()'%(i))[0].strip()
    #     print(lunci)                    # 轮次
    #     time1 = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[2]/span/text()[1]'%(i))[0].strip()
    #     time2 = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[2]/span/text()[2]'%(i))[0].strip()
    #     time = time1 +' ' + time2
    #     print(time)                     # 时间
    #     zhudui = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[3]/a/text()'%(i))[0].strip()
    #     zhudui_num = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[3]/a/span/text()'%(i))[0].strip()
    #     Zhu_Num = zhudui + zhudui_num
    #     print(Zhu_Num)                  # 主队
    #     bifen_all = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[4]/a/text()'%(i))[0].strip()
    #     bifen_ban = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[4]/a/span/text()'%(i))[0].strip()
    #     bifen = bifen_all + '(' + bifen_ban + ')'
    #     print(bifen)                    # 比分（半场）
    #     kedui = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[5]/a/text()'%(i))[0].strip()
    #     kedui_num = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[5]/a/span/text()'%(i))[0].strip()
    #     Kedui_Num = kedui + kedui_num
    #     print(Kedui_Num)                # 客队
    #     rangqiu = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[6]/div[1]/text()'%(i))[0].strip()
    #     print(rangqiu)                  # 让球
    #     jinqiu = html_ele.xpath('//*[@id="matches"]/table/tr[%d]/td[7]/div[1]/text()'%(i))[0].strip()
    #     print(jinqiu)
    #
    #     # 存储
    #     text = [lunci, time, Zhu_Num, bifen, Kedui_Num, rangqiu, jinqiu]
    #     save_mysql(text)
    #
    #     print('=+=' * 20)

    # 获取所有队伍编号

    div_list = html_ele.xpath('//*[@id="scoreboard"]/div[3]/div')
    print(type(div_list))
    team_list = []
    for div in div_list[:-1]:
        for j in range(2, 6):
            team_num = div.xpath('./table/tr[%d]/td[2]/a/@href' % (j))[0]
            # print(team_num)
            team_list.append(team_num)
    print(team_list)


# # 存储到mysql
# def save_mysql(text):
#     # 爬虫第五步
#     insert_sql = 'INSERT INTO leisu_worldcup_fenzu(lunci, time, zhudui, bifen, kedui, rangqiu, jinqiu) VALUES(%s, %s, %s, %s, %s, %s, %s);'
#     data = text
#     helper.execute_modify_sql(insert_sql, data)

# //*[@id="scoreboard"]/div[3]/div[1]/table/tbody/tr[2]/td[2]/a
# //*[@id="scoreboard"]/div[3]/div[1]/table/tbody/tr[3]/td[2]/a
# //*[@id="scoreboard"]/div[3]/div[1]/table/tbody/tr[5]/td[2]/a
#
# //*[@id="scoreboard"]/div[3]/div[2]/table/tbody/tr[2]/td[2]/a
# //*[@id="scoreboard"]/div[3]/div[2]/table/tbody/tr[5]/td[2]/a
#
# //*[@id="scoreboard"]/div[3]/div[3]/table/tbody/tr[2]/td[2]/a
# //*[@id="scoreboard"]/div[3]/div[8]/table/tbody/tr[2]/td[2]/a


if __name__ == '__main__':
    url = 'https://data.leisu.com/zuqiu-7555'
    parse_detailed_leisu(url)

